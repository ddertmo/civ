first go to the flutter dev then download the sdk
2nd extract where u pref
3rd when done extract go to bin and copy the directory of the folder
then go window search envir then search for path then click edit then new then paste the directory of the bin 
then press okay for all to the environment
then click ctrl R then cmd 
then put flutter --version
then if theres a result its installed
