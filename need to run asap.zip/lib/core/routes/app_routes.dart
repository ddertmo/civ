class AppRoutes {
  AppRoutes._();

  static const String splash = '/';
  static const String login = '/login';
  static const String otp = '/otp';
  static const String register = '/register';
  static const String home = '/home';

  // Report flow
  static const String reportCategory = '/report/category';
  static const String reportIssue = '/report/issue';
  static const String reportPhoto = '/report/photo';
  static const String reportDetails = '/report/details';
  static const String reportReview = '/report/review';
  static const String reportSubmitted = '/report/submitted';

  // Main tabs
  static const String myReports = '/my-reports';
  static const String trackReport = '/track-report';
  static const String privateMap = '/private-map';
  static const String communityMap = '/community-map';
  static const String notifications = '/notifications';
  static const String profile = '/profile';
}
