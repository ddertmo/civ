class AppImages {
  AppImages._();

  static const String _base = 'assets/images/';
  static const String _logos = 'assets/logos/';

  // ── Logos ─────────────────────────────────────────────────────────────────
  static const String logo = '${_logos}civilwatch_logo.png';
  static const String logoWhite = '${_logos}civilwatch_logo_white.png';

  // ── Illustrations ─────────────────────────────────────────────────────────
  static const String cityscape = '${_base}cityscape.png';
  static const String successIllustration = '${_base}success_illustration.png';
  static const String emptyReports = '${_base}empty_reports.png';
  static const String mapPlaceholder = '${_base}map_placeholder.png';
}
