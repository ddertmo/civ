class AppStrings {
  AppStrings._();

  // ── App ───────────────────────────────────────────────────────────────────
  static const String appName = 'CIVILWATCH';
  static const String appTagline =
      'Community Infrastructure &\nEnvironmental Incident Reporting System';
  static const String appCity = 'Digos City, Davao del Sur';

  // ── Auth ──────────────────────────────────────────────────────────────────
  static const String welcome = 'Welcome!';
  static const String loginSubtitle = 'Enter your mobile number\nto continue.';
  static const String mobileNumber = 'Mobile Number';
  static const String mobileHint = '9XX XXX XXXX';
  static const String sendOtp = 'Send OTP';
  static const String verifyOtp = 'Verify OTP';
  static const String otpSubtitle = "We've sent a 6-digit code to";
  static const String didntReceive = "Didn't receive the code?";
  static const String resendIn = 'Resend in';
  static const String verify = 'Verify';
  static const String back = 'Back';
  static const String termsText =
      'By continuing, you agree to the\n';
  static const String termsService = 'Terms of Service';
  static const String and = ' and ';
  static const String privacyPolicy = 'Privacy Policy';

  // ── Home ──────────────────────────────────────────────────────────────────
  static const String goodMorning = 'Good morning,';
  static const String goodAfternoon = 'Good afternoon,';
  static const String goodEvening = 'Good evening,';
  static const String homeSubtitle = 'Help make Digos City a better place.';
  static const String reportAnIncident = 'Report an Incident';
  static const String reportCta =
      'Tap to report infrastructure or environmental issues.';
  static const String myReports = 'My Reports';
  static const String viewAll = 'View All';
  static const String communityMap = 'Community Map';
  static const String viewMap = 'View Map';
  static const String latestAnnouncements = 'Latest Announcements';
  static const String pendingValidation = 'Pending Validation';
  static const String inProgress = 'In Progress';
  static const String resolved = 'Resolved';
  static const String totalReports = 'Total Reports';

  // ── Report Flow ───────────────────────────────────────────────────────────
  static const String reportIncident = 'Report Incident';
  static const String stepCategory = 'Category';
  static const String stepIssue = 'Issue';
  static const String stepPhoto = 'Photo';
  static const String stepDetails = 'Details';
  static const String stepReview = 'Review';
  static const String whatTypeOfIncident =
      'What type of incident\nwould you like to report?';
  static const String selectTheIssue = 'Select the issue';
  static const String selectIssueSubtitle =
      'Choose the specific issue you want\nto report.';
  static const String addAPhoto = 'Add a photo';
  static const String addPhotoSubtitle =
      'A clear photo helps us verify\nthe incident faster.';
  static const String takePhoto = 'Take Photo';
  static const String tapToCapture = 'Tap to capture';
  static const String or = 'or';
  static const String chooseFromGallery = 'Choose from Gallery';
  static const String photoTip =
      'Tip: Make sure the issue is clearly visible in the photo.';
  static const String incidentLocation = 'Incident Location';
  static const String useCurrentLocation = 'Use Current Location';
  static const String selectOnMap = 'Select on Map';
  static const String description = 'Description';
  static const String descriptionHint = 'Describe the issue...';
  static const String severity = 'Severity';
  static const String howSerious = 'How serious is this issue?';
  static const String minor = 'Minor';
  static const String moderate = 'Moderate';
  static const String severe = 'Severe';
  static const String reviewReport = 'Review Report';
  static const String reviewSubtitle = 'Please review your report\nbefore submitting.';
  static const String confirmAccuracy =
      'I confirm that the information provided\nis accurate and true.';
  static const String submitReport = 'Submit Report';
  static const String edit = 'Edit';
  static const String next = 'Next';
  static const String nextArrow = 'Next →';
  static const String backArrow = '← Back';

  // ── Report Submitted ──────────────────────────────────────────────────────
  static const String reportSubmitted = 'Report Submitted!';
  static const String reportSubmittedSubtitle =
      'Thank you for helping make\nDigos City a better place.';
  static const String referenceNumber = 'Reference Number';
  static const String submittedOn = 'Submitted on';
  static const String trackInMyReports =
      'You can track your report status\nin My Reports.';
  static const String goToMyReports = 'Go to My Reports';
  static const String backToHome = 'Back to Home';

  // ── My Reports ────────────────────────────────────────────────────────────
  static const String myReportsTitle = 'My Reports';
  static const String myReportsSubtitle =
      'Track the status of your reported incidents.';
  static const String searchReports = 'Search reports...';
  static const String filter = 'Filter';
  static const String all = 'All';
  static const String pending = 'Pending';

  // ── Track Report ─────────────────────────────────────────────────────────
  static const String trackReport = 'Track Report';
  static const String statusUpdate = 'Status Update';
  static const String trackSubtitle = 'Track the latest progress of your report.';
  static const String progressTimeline = 'Progress Timeline';
  static const String activityLog = 'Activity Log';
  static const String assignedOffice = 'Assigned Office';
  static const String incidentLocationLabel = 'Incident Location';
  static const String notYetAssigned = 'Not yet assigned';
  static const String assignedAfterValidation =
      'This report will be assigned to the appropriate office after validation.';
  static const String viewOnMap = 'View on Map';
  static const String backToMyReports = '← Back to My Reports';
  static const String viewAllActivity = 'View All Activity';
  static const String manageNotifications = 'Manage Notifications';
  static const String notifyBanner =
      'You will be notified whenever there is an update on your report.';

  // ── Private Map ──────────────────────────────────────────────────────────
  static const String reportLocation = 'Report Location';
  static const String pendingValidationBanner = 'Pending Validation';
  static const String onlyYouCanSee =
      'Only you can see this report until it has been validated.';
  static const String onlyVisibleToYou = 'Only visible to you';
  static const String backToReport = '← Back to Report';
  static const String barangayLabel = 'Barangay Aplaya';
  static const String digosCity = 'Digos City';
  static const String coordinates = 'Coordinates';
  static const String coordsValue = '6.xxxxxx, 125.xxxxxx';
  static const String submitted = 'Submitted';

  // ── Community Map ─────────────────────────────────────────────────────────
  static const String communityMapTitle = 'Community Map';
  static const String communityMapSubtitle = 'Digos City, Davao del Sur';
  static const String searchLocation = 'Search location';
  static const String layers = 'Layers';
  static const String myLocation = 'My Location';
  static const String infrastructure = 'Infrastructure';
  static const String environment = 'Environment';
  static const String others = 'Others';
  static const String filters = 'Filters';
  static const String recentReports = 'Recent Reports';
  static const String showingVisibleReports = 'Showing visible reports only';
  static const String validatedReportsNote =
      'Reports are visible on the map only after they have been validated.';

  // ── Notifications ─────────────────────────────────────────────────────────
  static const String notifications = 'Notifications';
  static const String markAllRead = 'Mark all read';
  static const String today = 'Today';
  static const String yesterday = 'Yesterday';
  static const String earlier = 'Earlier';

  // ── Profile ───────────────────────────────────────────────────────────────
  static const String profile = 'Profile';
  static const String myActivity = 'My Activity';
  static const String helpCenter = 'Help Center';
  static const String aboutCivilwatch = 'About CIVILWATCH';
  static const String logout = 'Logout';
  static const String editProfile = 'Edit Profile';
  static const String resident = 'Resident';

  // ── Barangays ─────────────────────────────────────────────────────────────
  static const List<String> barangays = [
    'Aplaya',
    'Badiang',
    'Balabag',
    'Binaton',
    'Cogon',
    'Colorado',
    'Dawis',
    'Dulangan',
    'Goma',
    'Igpit',
    'Kapatagan',
    'Kiagdan',
    'Matti',
    'New Visayas',
    'Rizal',
    'San Jose',
    'San Miguel',
    'Soong',
    'Tres de Mayo',
    'Zone 1',
    'Zone 2',
    'Zone 3',
  ];
}
