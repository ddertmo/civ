import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

class AppHelpers {
  AppHelpers._();

  // ── Date / Time ───────────────────────────────────────────────────────────
  static String formatDate(DateTime date) =>
      DateFormat('MMM d, yyyy').format(date);

  static String formatDateTime(DateTime date) =>
      DateFormat('MMM d, yyyy • h:mm a').format(date);

  static String formatTime(DateTime date) =>
      DateFormat('h:mm a').format(date);

  static String formatDateShort(DateTime date) =>
      DateFormat('MMM d').format(date);

  static String timeAgo(DateTime date) {
    final diff = DateTime.now().difference(date);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes} mins ago';
    if (diff.inHours < 24) return '${diff.inHours} hour${diff.inHours > 1 ? 's' : ''} ago';
    if (diff.inDays == 1) return 'Yesterday';
    if (diff.inDays < 7) return '${diff.inDays} days ago';
    return formatDate(date);
  }

  // ── Greeting ──────────────────────────────────────────────────────────────
  static String getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return AppStrings.goodMorning;
    if (hour < 17) return AppStrings.goodAfternoon;
    return AppStrings.goodEvening;
  }

  // ── Reference Number ──────────────────────────────────────────────────────
  static String generateRefNumber() {
    final year = DateTime.now().year;
    final seq = (DateTime.now().millisecondsSinceEpoch % 100000)
        .toString()
        .padLeft(5, '0');
    return 'CW-$year-$seq';
  }

  // ── Status Helpers ────────────────────────────────────────────────────────
  static Color getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'submitted':
        return AppColors.statusSubmitted;
      case 'pending validation':
      case 'pending':
        return AppColors.statusPending;
      case 'assigned to office':
      case 'assigned':
        return AppColors.statusAssigned;
      case 'in progress':
        return AppColors.statusInProgress;
      case 'resolved':
        return AppColors.statusResolved;
      default:
        return AppColors.textSecondary;
    }
  }

  static Color getStatusBgColor(String status) {
    switch (status.toLowerCase()) {
      case 'submitted':
        return AppColors.statusSubmittedBg;
      case 'pending validation':
      case 'pending':
        return AppColors.statusPendingBg;
      case 'assigned to office':
      case 'assigned':
        return AppColors.statusAssignedBg;
      case 'in progress':
        return AppColors.statusInProgressBg;
      case 'resolved':
        return AppColors.statusResolvedBg;
      default:
        return AppColors.background;
    }
  }

  static IconData getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'submitted':
        return Icons.check_circle_rounded;
      case 'pending validation':
      case 'pending':
        return Icons.hourglass_empty_rounded;
      case 'assigned to office':
      case 'assigned':
        return Icons.business_rounded;
      case 'in progress':
        return Icons.construction_rounded;
      case 'resolved':
        return Icons.task_alt_rounded;
      default:
        return Icons.circle_outlined;
    }
  }

  // ── Category Helpers ─────────────────────────────────────────────────────
  static Color getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'infrastructure':
        return AppColors.infrastructure;
      case 'environment':
        return AppColors.environment;
      default:
        return AppColors.textSecondary;
    }
  }

  static Color getCategoryBgColor(String category) {
    switch (category.toLowerCase()) {
      case 'infrastructure':
        return AppColors.infrastructureBg;
      case 'environment':
        return AppColors.environmentBg;
      default:
        return AppColors.background;
    }
  }

  static IconData getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'infrastructure':
        return Icons.construction_rounded;
      case 'environment':
        return Icons.eco_rounded;
      default:
        return Icons.more_horiz_rounded;
    }
  }

  static IconData getIssueIcon(String issue) {
    switch (issue.toLowerCase()) {
      case 'broken streetlight':
        return Icons.light_rounded;
      case 'damaged road':
        return Icons.add_road_rounded;
      case 'damaged sidewalk':
        return Icons.directions_walk_rounded;
      case 'blocked drainage':
        return Icons.water_rounded;
      case 'damaged bridge':
        return Icons.directions_rounded;
      case 'road sign damage':
        return Icons.signpost_rounded;
      case 'illegal dumping':
        return Icons.delete_rounded;
      case 'blocked canal':
        return Icons.water_damage_rounded;
      case 'overgrown vegetation':
        return Icons.grass_rounded;
      case 'soil erosion':
        return Icons.terrain_rounded;
      default:
        return Icons.more_horiz_rounded;
    }
  }

  // ── Snackbar ──────────────────────────────────────────────────────────────
  static void showSnack(BuildContext context, String message,
      {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? const Color(0xFFDC2626) : AppColors.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }
}
