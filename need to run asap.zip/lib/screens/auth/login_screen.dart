import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/routes/app_routes.dart';
import '../../core/utils/validators.dart';
import '../../widgets/buttons/primary_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  bool _isLoading = false;
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _animController, curve: Curves.easeOutCubic));
    _animController.forward();
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _animController.dispose();
    super.dispose();
  }

  void _sendOtp() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 1200));
    if (mounted) {
      setState(() => _isLoading = false);
      final phone = '+63 ${_phoneController.text.trim()}';
      Navigator.pushNamed(context, AppRoutes.otp, arguments: phone);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.loginBg,
      body: Stack(
        children: [
          // ── Background blobs ─────────────────────────────────────────────
          Positioned(
            top: -80,
            right: -80,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.loginBgDark.withOpacity(0.4),
              ),
            ),
          ),
          Positioned(
            top: -40,
            left: -60,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.primary.withOpacity(0.06),
              ),
            ),
          ),

          // ── City skyline illustration (bottom) ────────────────────────────
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: _CitySkyline(),
          ),

          // ── Main scroll content ───────────────────────────────────────────
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: FadeTransition(
                opacity: _fadeAnim,
                child: SlideTransition(
                  position: _slideAnim,
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 48),

                        // ── Logo + title ─────────────────────────────────
                        Center(
                          child: Column(
                            children: [
                              _LogoBadge(size: 90),
                              const SizedBox(height: 16),
                              Text(
                                'CIVILWATCH',
                                style: GoogleFonts.inter(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.navy,
                                  letterSpacing: 2,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Community Infrastructure &\nEnvironmental Incident Reporting System',
                                style: GoogleFonts.inter(
                                  fontSize: 13,
                                  color: AppColors.textSecondary,
                                  height: 1.5,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 40),

                        // ── Form card ─────────────────────────────────────
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.navy.withOpacity(0.08),
                                blurRadius: 24,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Welcome!',
                                style: GoogleFonts.inter(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Enter your mobile number\nto continue.',
                                style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: AppColors.textSecondary,
                                  height: 1.5,
                                ),
                              ),
                              const SizedBox(height: 24),

                              // Mobile number label
                              Text(
                                'Mobile Number',
                                style: GoogleFonts.inter(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 8),

                              // Phone input with +63 prefix
                              TextFormField(
                                controller: _phoneController,
                                keyboardType: TextInputType.phone,
                                validator: AppValidators.phoneNumber,
                                inputFormatters: [
                                  FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(10),
                                ],
                                style: GoogleFonts.inter(
                                  fontSize: 15,
                                  color: AppColors.textPrimary,
                                ),
                                decoration: InputDecoration(
                                  hintText: '9XX XXX XXXX',
                                  hintStyle: GoogleFonts.inter(
                                      fontSize: 14, color: AppColors.textHint),
                                  filled: true,
                                  fillColor: AppColors.inputFill,
                                  prefixIcon: Container(
                                    margin: const EdgeInsets.only(
                                        left: 12, right: 4),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 6),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        right: BorderSide(
                                            color: AppColors.inputBorder),
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          '+63',
                                          style: GoogleFonts.inter(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.textPrimary,
                                          ),
                                        ),
                                        const SizedBox(width: 4),
                                        const Icon(
                                            Icons.keyboard_arrow_down_rounded,
                                            size: 16,
                                            color: AppColors.textSecondary),
                                      ],
                                    ),
                                  ),
                                  suffixIcon: const Icon(Icons.phone_rounded,
                                      color: AppColors.textHint, size: 20),
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 14),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                        color: AppColors.inputBorder),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                        color: AppColors.inputBorder),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                        color: AppColors.navy, width: 1.5),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 24),

                              // Send OTP button
                              PrimaryButton(
                                label: 'Send OTP',
                                icon: Icons.send_rounded,
                                isLoading: _isLoading,
                                onPressed: _sendOtp,
                              ),
                              const SizedBox(height: 20),

                              // Terms
                              Center(
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: GoogleFonts.inter(
                                      fontSize: 12,
                                      color: AppColors.textSecondary,
                                    ),
                                    children: [
                                      const WidgetSpan(
                                        child: Padding(
                                          padding:
                                              EdgeInsets.only(right: 4),
                                          child: Icon(Icons.shield_outlined,
                                              size: 13,
                                              color: AppColors.textSecondary),
                                        ),
                                      ),
                                      const TextSpan(
                                          text:
                                              'By continuing, you agree to the\n'),
                                      TextSpan(
                                        text: 'Terms of Service',
                                        style: GoogleFonts.inter(
                                          fontSize: 12,
                                          color: AppColors.navy,
                                          fontWeight: FontWeight.w600,
                                          decoration:
                                              TextDecoration.underline,
                                        ),
                                      ),
                                      const TextSpan(text: ' and '),
                                      TextSpan(
                                        text: 'Privacy Policy',
                                        style: GoogleFonts.inter(
                                          fontSize: 12,
                                          color: AppColors.navy,
                                          fontWeight: FontWeight.w600,
                                          decoration:
                                              TextDecoration.underline,
                                        ),
                                      ),
                                      const TextSpan(text: '.'),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 200),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Logo Badge ───────────────────────────────────────────────────────────────
class _LogoBadge extends StatelessWidget {
  final double size;
  const _LogoBadge({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.navy,
        boxShadow: [
          BoxShadow(
            color: AppColors.navy.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Icon(Icons.shield_rounded,
              color: AppColors.white.withOpacity(0.12), size: size * 0.82),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.location_on_rounded,
                  color: AppColors.white, size: size * 0.28),
              Icon(Icons.eco_rounded,
                  color: AppColors.primary, size: size * 0.22),
            ],
          ),
        ],
      ),
    );
  }
}

// ── City Skyline illustration ─────────────────────────────────────────────────
class _CitySkyline extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(MediaQuery.of(context).size.width, 160),
      painter: _SkylinePainter(),
    );
  }
}

class _SkylinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final buildingPaint = Paint()..color = const Color(0xFFCFDDE8);
    final treePaint = Paint()..color = const Color(0xFFB5D4C0);
    final groundPaint = Paint()..color = const Color(0xFFD8EAF0);

    // Ground
    canvas.drawRect(
        Rect.fromLTWH(0, size.height * 0.7, size.width, size.height * 0.3),
        groundPaint);

    // Buildings
    final buildings = [
      [0.0, 0.4, 0.12, 0.3],
      [0.1, 0.25, 0.08, 0.45],
      [0.2, 0.3, 0.1, 0.4],
      [0.35, 0.15, 0.12, 0.55],
      [0.48, 0.35, 0.09, 0.35],
      [0.6, 0.2, 0.11, 0.5],
      [0.73, 0.38, 0.08, 0.32],
      [0.82, 0.28, 0.1, 0.42],
      [0.93, 0.4, 0.07, 0.3],
    ];

    for (final b in buildings) {
      canvas.drawRect(
        Rect.fromLTWH(
          size.width * b[0],
          size.height * b[1],
          size.width * b[2],
          size.height * b[3],
        ),
        buildingPaint,
      );
    }

    // Windows on buildings (tiny dots)
    final windowPaint = Paint()..color = const Color(0xFFE8F4FD).withOpacity(0.8);
    for (final b in buildings) {
      final bx = size.width * b[0];
      final by = size.height * b[1];
      final bw = size.width * b[2];
      final bh = size.height * b[3];
      for (var row = 0; row < 3; row++) {
        for (var col = 0; col < 2; col++) {
          canvas.drawRect(
            Rect.fromLTWH(
              bx + bw * 0.2 + col * bw * 0.45,
              by + bh * 0.15 + row * bh * 0.25,
              bw * 0.2,
              bh * 0.12,
            ),
            windowPaint,
          );
        }
      }
    }

    // Trees
    final treeTrunkPaint = Paint()..color = const Color(0xFFB5A08A);
    final treePositions = [0.05, 0.28, 0.52, 0.68, 0.88];
    for (final tx in treePositions) {
      final x = size.width * tx;
      final y = size.height * 0.58;
      // trunk
      canvas.drawRect(Rect.fromLTWH(x + 8, y + 22, 6, 16), treeTrunkPaint);
      // canopy
      canvas.drawCircle(Offset(x + 11, y + 16), 16, treePaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
