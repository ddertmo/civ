import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/dummy_data.dart';
import '../../core/utils/helpers.dart';
import '../../widgets/map/filter_chip.dart';

class CommunityMapScreen extends StatefulWidget {
  final bool embedded;
  const CommunityMapScreen({super.key, this.embedded = false});

  @override
  State<CommunityMapScreen> createState() => _CommunityMapScreenState();
}

class _CommunityMapScreenState extends State<CommunityMapScreen> {
  String _activeFilter = 'All';
  MapPin? _selectedPin;

  List<MapPin> get _filteredPins {
    if (_activeFilter == 'All') return DummyData.communityPins;
    return DummyData.communityPins
        .where((p) => p.category == _activeFilter)
        .toList();
  }

  int get _infraCount =>
      DummyData.communityPins.where((p) => p.category == 'Infrastructure').length;
  int get _envCount =>
      DummyData.communityPins.where((p) => p.category == 'Environment').length;
  // ignore: unused_element

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _MapHeader(embedded: widget.embedded),
            _FilterRow(
              activeFilter: _activeFilter,
              onChanged: (f) => setState(() {
                _activeFilter = f;
                _selectedPin = null;
              }),
            ),
            Expanded(
              child: Stack(
                children: [
                  _CommunityMapBody(
                    pins: _filteredPins,
                    selectedPin: _selectedPin,
                    onPinTap: (p) => setState(() =>
                        _selectedPin = _selectedPin?.id == p.id ? null : p),
                  ),
                  if (_selectedPin != null)
                    Positioned(
                      top: 12,
                      left: 16,
                      right: 16,
                      child: _PinDetailCard(
                        pin: _selectedPin!,
                        onClose: () => setState(() => _selectedPin = null),
                      ),
                    ),
                ],
              ),
            ),
            _RecentReportsSheet(
              infraCount: _infraCount,
              envCount: _envCount,
              total: DummyData.communityPins.length,
            ),
          ],
        ),
      ),
    );
  }
}

class _MapHeader extends StatelessWidget {
  final bool embedded;
  const _MapHeader({required this.embedded});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.white,
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
      child: Row(
        children: [
          if (!embedded)
            IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
              onPressed: () => Navigator.pop(context),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
          if (!embedded) const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Community Map',
                    style: GoogleFonts.inter(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary)),
                Row(children: [
                  const Icon(Icons.location_on_rounded,
                      size: 12, color: AppColors.textSecondary),
                  const SizedBox(width: 3),
                  Text('Digos City, Davao del Sur',
                      style: GoogleFonts.inter(
                          fontSize: 11, color: AppColors.textSecondary)),
                ]),
              ],
            ),
          ),
          Stack(clipBehavior: Clip.none, children: [
            const Icon(Icons.notifications_outlined,
                color: AppColors.textPrimary, size: 26),
            Positioned(
              top: -2,
              right: -2,
              child: Container(
                width: 10,
                height: 10,
                decoration: const BoxDecoration(
                    color: AppColors.statusResolved,
                    shape: BoxShape.circle),
              ),
            ),
          ]),
        ],
      ),
    );
  }
}

class _FilterRow extends StatelessWidget {
  final String activeFilter;
  final void Function(String) onChanged;
  const _FilterRow({required this.activeFilter, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.white,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Row(
        children: [
          MapFilterChip(
            label: 'All',
            isSelected: activeFilter == 'All',
            onTap: () => onChanged('All'),
            icon: Icons.grid_view_rounded,
          ),
          const SizedBox(width: 8),
          MapFilterChip(
            label: 'Infrastructure',
            isSelected: activeFilter == 'Infrastructure',
            onTap: () => onChanged('Infrastructure'),
            icon: Icons.construction_rounded,
            activeColor: AppColors.white,
            activeBg: AppColors.infrastructure,
          ),
          const SizedBox(width: 8),
          MapFilterChip(
            label: 'Environment',
            isSelected: activeFilter == 'Environment',
            onTap: () => onChanged('Environment'),
            icon: Icons.eco_rounded,
            activeColor: AppColors.white,
            activeBg: AppColors.environment,
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.divider),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.filter_list_rounded,
                  size: 14, color: AppColors.textSecondary),
              const SizedBox(width: 4),
              Text('Filters',
                  style: GoogleFonts.inter(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary)),
            ]),
          ),
        ],
      ),
    );
  }
}

class _CommunityMapBody extends StatelessWidget {
  final List<MapPin> pins;
  final MapPin? selectedPin;
  final void Function(MapPin) onPinTap;

  const _CommunityMapBody(
      {required this.pins, this.selectedPin, required this.onPinTap});

  static const List<_PinPos> _positions = [
    _PinPos(id: 'p-001', dx: 0.35, dy: 0.45),
    _PinPos(id: 'p-002', dx: 0.62, dy: 0.22),
    _PinPos(id: 'p-003', dx: 0.48, dy: 0.35),
    _PinPos(id: 'p-004', dx: 0.28, dy: 0.62),
    _PinPos(id: 'p-005', dx: 0.55, dy: 0.55),
    _PinPos(id: 'p-006', dx: 0.42, dy: 0.72),
    _PinPos(id: 'p-007', dx: 0.72, dy: 0.50),
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (ctx, constraints) {
      final w = constraints.maxWidth;
      final h = constraints.maxHeight;
      return Stack(children: [
        // Map background
        SizedBox.expand(
          child: CustomPaint(painter: _CommunityMapPainter()),
        ),
        // Search bar
        Positioned(
          top: 12, left: 12,
          child: _SearchBarOverlay(),
        ),
        // My Location button
        Positioned(
          right: 12, bottom: 48,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [BoxShadow(color: AppColors.cardShadow, blurRadius: 6)],
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.my_location_rounded, size: 16, color: AppColors.navy),
              const SizedBox(width: 6),
              Text('My Location',
                  style: GoogleFonts.inter(
                      fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.navy)),
            ]),
          ),
        ),
        // Zoom controls
        Positioned(
          right: 12, bottom: 96,
          child: Column(children: [
            _ZoomBtn(icon: Icons.add_rounded),
            const SizedBox(height: 4),
            _ZoomBtn(icon: Icons.remove_rounded),
          ]),
        ),
        // Showing label
        Positioned(
          bottom: 12, left: 0, right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: AppColors.white.withOpacity(0.9),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.divider),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.visibility_rounded, size: 14, color: AppColors.textSecondary),
                const SizedBox(width: 6),
                Text('Showing visible reports only',
                    style: GoogleFonts.inter(fontSize: 11, color: AppColors.textSecondary)),
              ]),
            ),
          ),
        ),
        // Pins
        ...pins.map((pin) {
          final pos = _positions.firstWhere((p) => p.id == pin.id,
              orElse: () => _PinPos(id: pin.id, dx: 0.5, dy: 0.5));
          final isSelected = selectedPin?.id == pin.id;
          final color = AppHelpers.getCategoryColor(pin.category);
          final icon = AppHelpers.getIssueIcon(pin.issue);
          return Positioned(
            left: w * pos.dx - (isSelected ? 25 : 21),
            top: h * pos.dy - (isSelected ? 25 : 21),
            child: GestureDetector(
              onTap: () => onPinTap(pin),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: isSelected ? 50 : 42,
                  height: isSelected ? 50 : 42,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.white, width: 2),
                    boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 8, offset: const Offset(0, 3))],
                  ),
                  child: Icon(icon, color: AppColors.white, size: isSelected ? 26 : 20),
                ),
                CustomPaint(
                  size: Size(isSelected ? 14 : 10, isSelected ? 10 : 7),
                  painter: _TailPainter(color: color),
                ),
              ]),
            ),
          );
        }),
      ]);
    });
  }
}

class _PinPos {
  final String id;
  final double dx, dy;
  const _PinPos({required this.id, required this.dx, required this.dy});
}

class _PinDetailCard extends StatelessWidget {
  final MapPin pin;
  final VoidCallback onClose;
  const _PinDetailCard({required this.pin, required this.onClose});

  @override
  Widget build(BuildContext context) {
    final color = AppHelpers.getCategoryColor(pin.category);
    final catBg = AppHelpers.getCategoryBgColor(pin.category);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: const [BoxShadow(color: AppColors.cardShadow, blurRadius: 10, offset: Offset(0, 3))],
      ),
      child: Row(children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(color: catBg, shape: BoxShape.circle),
          child: Icon(AppHelpers.getIssueIcon(pin.issue), color: color, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(pin.issue, style: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          Text(pin.category, style: GoogleFonts.inter(fontSize: 11, color: AppColors.textSecondary)),
          Row(children: [
            Container(width: 6, height: 6, decoration: BoxDecoration(color: AppHelpers.getStatusColor(pin.status), shape: BoxShape.circle)),
            const SizedBox(width: 4),
            Text(pin.status, style: GoogleFonts.inter(fontSize: 10, fontWeight: FontWeight.w600, color: AppHelpers.getStatusColor(pin.status))),
            const SizedBox(width: 8),
            Text('• Brgy. ${pin.barangay}', style: GoogleFonts.inter(fontSize: 10, color: AppColors.textHint)),
          ]),
        ])),
        IconButton(icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textHint), onPressed: onClose),
      ]),
    );
  }
}

class _SearchBarOverlay extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [BoxShadow(color: AppColors.cardShadow, blurRadius: 6)],
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.search_rounded, size: 16, color: AppColors.textHint),
        const SizedBox(width: 6),
        Text('Search location', style: GoogleFonts.inter(fontSize: 12, color: AppColors.textHint)),
      ]),
    );
  }
}

class _ZoomBtn extends StatelessWidget {
  final IconData icon;
  const _ZoomBtn({required this.icon});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 34, height: 34,
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: const [BoxShadow(color: AppColors.cardShadow, blurRadius: 4)],
      ),
      child: Icon(icon, size: 20, color: AppColors.textPrimary),
    );
  }
}

class _RecentReportsSheet extends StatelessWidget {
  final int infraCount, envCount, total;
  const _RecentReportsSheet({required this.infraCount, required this.envCount, required this.total});

  @override
  Widget build(BuildContext context) {
    final reports = DummyData.myReports;
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.white,
        border: Border(top: BorderSide(color: AppColors.divider)),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        // Handle
        Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 4),
          child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(2))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(children: [
            Text('Recent Reports', style: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
            const Spacer(),
            Text('View All', style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.primary)),
            const Icon(Icons.chevron_right_rounded, size: 16, color: AppColors.primary),
          ]),
        ),
        SizedBox(
          height: 130,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            itemCount: reports.length,
            itemBuilder: (ctx, i) {
              final r = reports[i];
              final catColor = AppHelpers.getCategoryColor(r.category);
              final statusColor = AppHelpers.getStatusColor(r.status);
              return Container(
                width: 120,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  color: AppColors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.divider),
                ),
                child: Column(children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                    child: Container(height: 60, color: const Color(0xFF1A2A3A),
                        child: Center(child: Icon(AppHelpers.getCategoryIcon(r.category), color: AppColors.white.withOpacity(0.4), size: 24))),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(6),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Icon(AppHelpers.getCategoryIcon(r.category), size: 10, color: catColor),
                        const SizedBox(width: 3),
                        Expanded(child: Text(r.issue, style: GoogleFonts.inter(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.textPrimary), maxLines: 1, overflow: TextOverflow.ellipsis)),
                      ]),
                      Text('Brgy. ${r.barangay}', style: GoogleFonts.inter(fontSize: 9, color: AppColors.textHint)),
                      Row(children: [
                        Container(width: 5, height: 5, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)),
                        const SizedBox(width: 3),
                        Text(r.status == 'Pending Validation' ? 'Pending' : r.status,
                            style: GoogleFonts.inter(fontSize: 9, fontWeight: FontWeight.w600, color: statusColor)),
                      ]),
                    ]),
                  ),
                ]),
              );
            },
          ),
        ),
        Container(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: AppColors.primarySurface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.primary.withOpacity(0.2)),
          ),
          child: Row(children: [
            const Icon(Icons.shield_rounded, size: 14, color: AppColors.primary),
            const SizedBox(width: 8),
            Expanded(child: Text('Reports are visible on the map only after they have been validated.',
                style: GoogleFonts.inter(fontSize: 11, color: AppColors.primary))),
          ]),
        ),
      ]),
    );
  }
}

class _TailPainter extends CustomPainter {
  final Color color;
  const _TailPainter({required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()..moveTo(0, 0)..lineTo(size.width, 0)..lineTo(size.width / 2, size.height)..close();
    canvas.drawPath(path, Paint()..color = color);
  }
  @override
  bool shouldRepaint(_) => false;
}

class _CommunityMapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = const Color(0xFFEEF2F7));
    final road = Paint()..color = AppColors.white..strokeWidth = 9..style = PaintingStyle.stroke;
    final minor = Paint()..color = AppColors.white..strokeWidth = 4..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(0, size.height * 0.5), Offset(size.width, size.height * 0.5), road);
    canvas.drawLine(Offset(size.width * 0.42, 0), Offset(size.width * 0.42, size.height), road);
    canvas.drawLine(Offset(0, size.height * 0.28), Offset(size.width, size.height * 0.28), minor);
    canvas.drawLine(Offset(0, size.height * 0.72), Offset(size.width, size.height * 0.72), minor);
    canvas.drawLine(Offset(size.width * 0.7, 0), Offset(size.width * 0.7, size.height), minor);
    final river = Paint()..color = const Color(0xFFB3D4E8)..strokeWidth = 14..style = PaintingStyle.stroke;
    final p = Path()..moveTo(size.width * 0.1, 0)..quadraticBezierTo(size.width * 0.5, size.height * 0.45, size.width, size.height * 0.58);
    canvas.drawPath(p, river);
    final block = Paint()..color = const Color(0xFFD0DAE0).withOpacity(0.6);
    for (final b in [[0.0,0.0,0.4,0.26],[0.44,0.0,0.24,0.26],[0.7,0.0,0.3,0.26],[0.0,0.3,0.2,0.18],[0.44,0.3,0.24,0.18],[0.72,0.3,0.26,0.18],[0.0,0.55,0.4,0.15],[0.44,0.55,0.54,0.15],[0.0,0.75,0.4,0.25],[0.44,0.75,0.54,0.25]]) {
      canvas.drawRect(Rect.fromLTWH(size.width * b[0]+2, size.height * b[1]+2, size.width * b[2]-4, size.height * b[3]-4), block);
    }
    final tp = TextPainter(text: TextSpan(text: 'Digos City', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: const Color(0xFF7A8A96).withOpacity(0.8))), textDirection: TextDirection.ltr)..layout();
    tp.paint(canvas, Offset(size.width * 0.42 - tp.width / 2, size.height * 0.5 + 10));
  }
  @override
  bool shouldRepaint(_) => false;
}
