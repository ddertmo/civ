import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/routes/app_routes.dart';
import '../../widgets/navigation/app_bar.dart';
import '_report_stepper.dart';

class ReportCategoryScreen extends StatefulWidget {
  const ReportCategoryScreen({super.key});

  @override
  State<ReportCategoryScreen> createState() => _ReportCategoryScreenState();
}

class _ReportCategoryScreenState extends State<ReportCategoryScreen> {
  String? _selected;

  void _next() {
    if (_selected == null) return;
    Navigator.pushNamed(context, AppRoutes.reportIssue,
        arguments: {'category': _selected});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: CivilWatchAppBar(
        title: 'Report Incident',
        subtitle: 'Step 1 of 5',
      ),
      body: Column(
        children: [
          // Stepper
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: ReportStepper(currentStep: 0),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'What type of incident\nwould you like to report?',
                    style: GoogleFonts.inter(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 28),

                  _CategoryCard(
                    title: 'Infrastructure',
                    subtitle:
                        'Roads, sidewalks, streetlights, drainage, bridges, and other public structures.',
                    icon: Icons.construction_rounded,
                    color: AppColors.infrastructure,
                    bg: AppColors.infrastructureBg,
                    isSelected: _selected == 'Infrastructure',
                    onTap: () => setState(() => _selected = 'Infrastructure'),
                  ),
                  const SizedBox(height: 14),
                  _CategoryCard(
                    title: 'Environment',
                    subtitle:
                        'Illegal dumping, overgrown vegetation, blocked canals, soil erosion, and more.',
                    icon: Icons.eco_rounded,
                    color: AppColors.environment,
                    bg: AppColors.environmentBg,
                    isSelected: _selected == 'Environment',
                    onTap: () => setState(() => _selected = 'Environment'),
                  ),
                ],
              ),
            ),
          ),

          // Bottom button
          _ReportNavBar(
            showBack: false,
            onNext: _selected != null ? _next : null,
          ),
        ],
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final Color bg;
  final bool isSelected;
  final VoidCallback onTap;

  const _CategoryCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.bg,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? color : AppColors.divider,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: isSelected
                  ? color.withOpacity(0.12)
                  : AppColors.cardShadow,
              blurRadius: isSelected ? 12 : 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: isSelected ? color : AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(
              Icons.chevron_right_rounded,
              color: isSelected ? color : AppColors.textHint,
              size: 22,
            ),
          ],
        ),
      ),
    );
  }
}

// ── Shared bottom nav bar for report flow ─────────────────────────────────────
class _ReportNavBar extends StatelessWidget {
  final bool showBack;
  final VoidCallback? onBack;
  final VoidCallback? onNext;
  final String nextLabel;
  final Color? nextColor;

  const _ReportNavBar({
    this.showBack = true,
    this.onBack,
    this.onNext,
    this.nextLabel = 'Next →',
    this.nextColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      decoration: const BoxDecoration(
        color: AppColors.white,
        border: Border(top: BorderSide(color: AppColors.divider)),
      ),
      child: Row(
        children: [
          if (showBack)
            Expanded(
              child: OutlinedButton.icon(
                onPressed: onBack ?? () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back_rounded, size: 18),
                label: const Text('Back'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.textPrimary,
                  side: const BorderSide(color: AppColors.divider),
                  minimumSize: const Size(0, 50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  textStyle: GoogleFonts.inter(
                      fontSize: 14, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          if (showBack) const SizedBox(width: 12),
          Expanded(
            flex: showBack ? 2 : 1,
            child: ElevatedButton.icon(
              onPressed: onNext,
              icon: const Icon(Icons.arrow_forward_rounded, size: 18),
              label: Text(nextLabel),
              style: ElevatedButton.styleFrom(
                backgroundColor: onNext != null
                    ? (nextColor ?? AppColors.primary)
                    : AppColors.textDisabled,
                foregroundColor: AppColors.white,
                minimumSize: const Size(0, 50),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 0,
                textStyle: GoogleFonts.inter(
                    fontSize: 14, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
