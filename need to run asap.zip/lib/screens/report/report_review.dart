import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/routes/app_routes.dart';
import '../../core/utils/helpers.dart';
import '../../widgets/navigation/app_bar.dart';
import '_report_stepper.dart';

class ReportReviewScreen extends StatefulWidget {
  final Map<String, dynamic> reportData;
  const ReportReviewScreen({super.key, required this.reportData});

  @override
  State<ReportReviewScreen> createState() => _ReportReviewScreenState();
}

class _ReportReviewScreenState extends State<ReportReviewScreen> {
  bool _confirmed = false;
  bool _isSubmitting = false;

  void _submit() async {
    if (!_confirmed) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please confirm the information is accurate.'),
          backgroundColor: const Color(0xFFDC2626),
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          margin: const EdgeInsets.all(16),
        ),
      );
      return;
    }
    setState(() => _isSubmitting = true);
    await Future.delayed(const Duration(milliseconds: 1500));
    if (mounted) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        AppRoutes.reportSubmitted,
        (r) => r.settings.name == AppRoutes.home,
        arguments: {
          ...widget.reportData,
          'referenceNumber': AppHelpers.generateRefNumber(),
          'submittedAt': DateTime.now().toIso8601String(),
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = widget.reportData;
    final category = data['category'] as String? ?? 'Infrastructure';
    final issue = data['issue'] as String? ?? '';
    final barangay = data['barangay'] as String? ?? 'Aplaya';
    final description = data['description'] as String? ?? '';
    final severity = data['severity'] as String? ?? 'Moderate';
    final catColor = AppHelpers.getCategoryColor(category);
    final catBg = AppHelpers.getCategoryBgColor(category);
    final catIcon = AppHelpers.getCategoryIcon(category);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: CivilWatchAppBar(
        title: 'Review Report',
        subtitle: 'Step 5 of 5',
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: ReportStepper(currentStep: 4),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Please review your report\nbefore submitting.',
                    style: GoogleFonts.inter(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // ── Review card ───────────────────────────────────────
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.divider),
                    ),
                    child: Column(
                      children: [
                        _ReviewRow(
                          icon: catIcon,
                          label: 'Category',
                          value: category,
                          valueColor: catColor,
                          valueBg: catBg,
                          isChip: true,
                          onEdit: () => Navigator.popUntil(context,
                              (r) => r.settings.name == AppRoutes.reportCategory),
                        ),
                        _Divider(),
                        _ReviewRow(
                          icon: AppHelpers.getIssueIcon(issue),
                          label: 'Issue',
                          value: issue,
                          onEdit: () => Navigator.pop(context),
                        ),
                        _Divider(),
                        _ReviewPhotoRow(hasPhoto: data['hasPhoto'] == true),
                        _Divider(),
                        _ReviewRow(
                          icon: Icons.location_on_rounded,
                          label: 'Location',
                          value: 'Barangay $barangay, Digos City',
                          valueSubtitle: '(Approximate location)',
                          onEdit: () => Navigator.pop(context),
                        ),
                        _Divider(),
                        _ReviewRow(
                          icon: Icons.chat_bubble_outline_rounded,
                          label: 'Description',
                          value: description.isEmpty
                              ? 'No description provided'
                              : description,
                          onEdit: () => Navigator.pop(context),
                          isMultiLine: true,
                        ),
                        _Divider(),
                        _ReviewSeverityRow(
                          severity: severity,
                          onEdit: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // ── Confirmation checkbox ─────────────────────────────
                  GestureDetector(
                    onTap: () =>
                        setState(() => _confirmed = !_confirmed),
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: _confirmed
                            ? AppColors.primarySurface
                            : AppColors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _confirmed
                              ? AppColors.primary
                              : AppColors.divider,
                          width: _confirmed ? 1.5 : 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 22,
                            height: 22,
                            decoration: BoxDecoration(
                              color: _confirmed
                                  ? AppColors.primary
                                  : AppColors.white,
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: _confirmed
                                    ? AppColors.primary
                                    : AppColors.inputBorder,
                                width: 1.5,
                              ),
                            ),
                            child: _confirmed
                                ? const Icon(Icons.check_rounded,
                                    color: AppColors.white, size: 14)
                                : null,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'I confirm that the information provided\nis accurate and true.',
                              style: GoogleFonts.inter(
                                fontSize: 13,
                                color: AppColors.textPrimary,
                                fontWeight: FontWeight.w500,
                                height: 1.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),

          // ── Bottom buttons ────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            decoration: const BoxDecoration(
              color: AppColors.white,
              border: Border(top: BorderSide(color: AppColors.divider)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.edit_rounded, size: 18),
                    label: const Text('Edit'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.textPrimary,
                      side: const BorderSide(color: AppColors.divider),
                      minimumSize: const Size(0, 50),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      textStyle: GoogleFonts.inter(
                          fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: _isSubmitting ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: AppColors.white,
                      minimumSize: const Size(0, 50),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      elevation: 0,
                    ),
                    child: _isSubmitting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: AppColors.white),
                          )
                        : Text(
                            'Submit Report',
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                fontWeight: FontWeight.w700),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) =>
      const Divider(height: 1, color: AppColors.divider);
}

class _ReviewRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String? valueSubtitle;
  final Color? valueColor;
  final Color? valueBg;
  final bool isChip;
  final bool isMultiLine;
  final VoidCallback? onEdit;

  const _ReviewRow({
    required this.icon,
    required this.label,
    required this.value,
    this.valueSubtitle,
    this.valueColor,
    this.valueBg,
    this.isChip = false,
    this.isMultiLine = false,
    this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: AppColors.textSecondary),
          const SizedBox(width: 12),
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: GoogleFonts.inter(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (isChip)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: valueBg,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      value,
                      style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: valueColor),
                    ),
                  )
                else
                  Text(
                    value,
                    style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary),
                    maxLines: isMultiLine ? 4 : 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                if (valueSubtitle != null)
                  Text(
                    valueSubtitle!,
                    style: GoogleFonts.inter(
                        fontSize: 11, color: AppColors.textHint),
                  ),
              ],
            ),
          ),
          if (onEdit != null)
            GestureDetector(
              onTap: onEdit,
              child: Text(
                'Edit',
                style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary),
              ),
            ),
        ],
      ),
    );
  }
}

class _ReviewPhotoRow extends StatelessWidget {
  final bool hasPhoto;
  const _ReviewPhotoRow({required this.hasPhoto});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.camera_alt_rounded,
              size: 18, color: AppColors.textSecondary),
          const SizedBox(width: 12),
          const SizedBox(
            width: 80,
            child: Text('Photo',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w500)),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: hasPhoto
                ? Container(
                    height: 64,
                    width: 80,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A2A3A),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.image_rounded,
                        color: AppColors.white, size: 28),
                  )
                : Text(
                    'No photo added',
                    style: GoogleFonts.inter(
                        fontSize: 13, color: AppColors.textHint),
                  ),
          ),
          Text('Edit',
              style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.primary)),
        ],
      ),
    );
  }
}

class _ReviewSeverityRow extends StatelessWidget {
  final String severity;
  final VoidCallback onEdit;

  const _ReviewSeverityRow(
      {required this.severity, required this.onEdit});

  Color get _color {
    switch (severity) {
      case 'Minor':
        return AppColors.statusResolved;
      case 'Severe':
        return AppColors.statusInProgress;
      default:
        return AppColors.statusPending;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          const Icon(Icons.shield_outlined,
              size: 18, color: AppColors.textSecondary),
          const SizedBox(width: 12),
          const SizedBox(
            width: 80,
            child: Text('Severity',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w500)),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Row(
              children: [
                Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                        color: _color, shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Text(
                  severity,
                  style: GoogleFonts.inter(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: _color),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onEdit,
            child: Text('Edit',
                style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary)),
          ),
        ],
      ),
    );
  }
}
