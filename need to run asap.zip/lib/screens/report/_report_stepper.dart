import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';

class ReportStepper extends StatelessWidget {
  final int currentStep; // 0-indexed: 0=Category,1=Issue,2=Photo,3=Details,4=Review

  const ReportStepper({super.key, required this.currentStep});

  static const _labels = ['Category', 'Issue', 'Photo', 'Details', 'Review'];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(_labels.length, (i) {
        final isDone = i < currentStep;
        final isCurrent = i == currentStep;
        final isLast = i == _labels.length - 1;

        return Expanded(
          child: Row(
            children: [
              Expanded(
                child: Column(
                  children: [
                    // Circle
                    Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: isDone || isCurrent
                            ? AppColors.primary
                            : AppColors.divider,
                        shape: BoxShape.circle,
                      ),
                      child: isDone
                          ? const Icon(Icons.check_rounded,
                              color: AppColors.white, size: 14)
                          : Center(
                              child: Container(
                                width: isCurrent ? 10 : 8,
                                height: isCurrent ? 10 : 8,
                                decoration: BoxDecoration(
                                  color: isCurrent
                                      ? AppColors.white
                                      : AppColors.textDisabled,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _labels[i],
                      style: GoogleFonts.inter(
                        fontSize: 9,
                        fontWeight: isCurrent
                            ? FontWeight.w700
                            : FontWeight.w400,
                        color: isDone || isCurrent
                            ? AppColors.primary
                            : AppColors.textHint,
                      ),
                    ),
                  ],
                ),
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    height: 2,
                    margin: const EdgeInsets.only(bottom: 16),
                    color: i < currentStep
                        ? AppColors.primary
                        : AppColors.divider,
                  ),
                ),
            ],
          ),
        );
      }),
    );
  }
}
