import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:ui';
import '../../core/constants/app_colors.dart';
import '../../core/utils/dummy_data.dart';
import '../../core/utils/helpers.dart';
import '../../models/report.dart';

class PrivateMapScreen extends StatelessWidget {
  final Map<String, dynamic> reportData;
  const PrivateMapScreen({super.key, required this.reportData});

  IncidentReport _getReport() {
    final id = reportData['reportId'] as String?;
    if (id != null) {
      return DummyData.myReports.firstWhere(
        (r) => r.id == id,
        orElse: () => DummyData.myReports.first,
      );
    }
    return DummyData.myReports.first;
  }

  @override
  Widget build(BuildContext context) {
    final report = _getReport();
    final pinColor = AppHelpers.getStatusColor(report.status);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              size: 20, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Report Location',
              style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary),
            ),
          ],
        ),
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(1),
          child: Divider(height: 1, color: AppColors.divider),
        ),
      ),
      body: Column(
        children: [
          // ── Warning banner ────────────────────────────────────────────
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.statusPendingBg,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.statusPendingBorder),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: AppColors.statusPending.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.warning_rounded,
                      color: AppColors.statusPending, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Pending Validation',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.statusPending,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Only you can see this report until it has been validated.',
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Icon(Icons.lock_rounded,
                    color: AppColors.statusPending.withOpacity(0.4),
                    size: 28),
              ],
            ),
          ),

          // ── Map ───────────────────────────────────────────────────────
          Expanded(
            child: Stack(
              children: [
                // Blurred map
                ClipRRect(
                  child: SizedBox.expand(
                    child: Stack(
                      children: [
                        // Map bg
                        CustomPaint(
                          painter: _PrivateMapPainter(),
                          child: Container(),
                        ),

                        // Blur filter
                        BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 2.5, sigmaY: 2.5),
                          child: Container(
                              color: Colors.black.withOpacity(0.05)),
                        ),

                        // Location crosshair button
                        Positioned(
                          top: 12,
                          left: 12,
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: const [
                                BoxShadow(
                                    color: AppColors.cardShadow,
                                    blurRadius: 6)
                              ],
                            ),
                            child: const Icon(Icons.my_location_rounded,
                                size: 20,
                                color: AppColors.textPrimary),
                          ),
                        ),

                        // Map type button
                        Positioned(
                          top: 12,
                          right: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: const [
                                BoxShadow(
                                    color: AppColors.cardShadow,
                                    blurRadius: 6)
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.layers_rounded,
                                    size: 16,
                                    color: AppColors.textPrimary),
                                const SizedBox(width: 4),
                                Text('Map',
                                    style: GoogleFonts.inter(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.textPrimary)),
                              ],
                            ),
                          ),
                        ),

                        // Zoom controls
                        Positioned(
                          right: 12,
                          bottom: 80,
                          child: Column(
                            children: [
                              _MapControlBtn(icon: Icons.add_rounded),
                              const SizedBox(height: 4),
                              _MapControlBtn(icon: Icons.remove_rounded),
                            ],
                          ),
                        ),

                        // Pin + popup at center
                        Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              _PinPopup(
                                issue: report.issue,
                                status: report.status,
                                showVisibleToYou: true,
                              ),
                              const SizedBox(height: 4),
                              _MapPin(color: pinColor, icon: AppHelpers.getIssueIcon(report.issue)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Bottom sheet handle
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    decoration: const BoxDecoration(
                      color: AppColors.white,
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(20)),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(height: 10),
                        Container(
                          width: 36,
                          height: 4,
                          decoration: BoxDecoration(
                            color: AppColors.divider,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        _LocationRow(
                          icon: Icons.location_on_rounded,
                          label: 'Barangay ${report.barangay}',
                          subtitle: 'Digos City',
                        ),
                        const Divider(
                            height: 1,
                            color: AppColors.divider,
                            indent: 20,
                            endIndent: 20),
                        _LocationRow(
                          icon: Icons.my_location_rounded,
                          label: 'Coordinates',
                          subtitle:
                              '${report.latitude.toStringAsFixed(4)}, ${report.longitude.toStringAsFixed(4)}',
                        ),
                        const Divider(
                            height: 1,
                            color: AppColors.divider,
                            indent: 20,
                            endIndent: 20),
                        _LocationRow(
                          icon: Icons.calendar_today_rounded,
                          label: 'Submitted',
                          subtitle: AppHelpers.formatDateTime(
                              report.submittedAt),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ── Back to Report button ──────────────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            color: AppColors.white,
            child: SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.map_rounded, size: 20),
                label: const Text('Back to Report'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.navy,
                  foregroundColor: AppColors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  elevation: 0,
                  textStyle: GoogleFonts.inter(
                      fontSize: 15, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PinPopup extends StatelessWidget {
  final String issue;
  final String status;
  final bool showVisibleToYou;

  const _PinPopup({
    required this.issue,
    required this.status,
    this.showVisibleToYou = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = AppHelpers.getStatusColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: const [
          BoxShadow(
              color: AppColors.cardShadow,
              blurRadius: 10,
              offset: Offset(0, 3))
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: AppHelpers.getStatusBgColor(status),
              shape: BoxShape.circle,
            ),
            child: Icon(AppHelpers.getIssueIcon(issue),
                size: 16, color: color),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                issue,
                style: GoogleFonts.inter(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary),
              ),
              Row(
                children: [
                  Container(
                    width: 7,
                    height: 7,
                    decoration:
                        BoxDecoration(color: color, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    status == 'Pending Validation' ? 'Pending Validation' : status,
                    style: GoogleFonts.inter(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: color),
                  ),
                ],
              ),
              if (showVisibleToYou)
                Text(
                  'Only visible to you',
                  style: GoogleFonts.inter(
                      fontSize: 10, color: AppColors.textHint),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MapPin extends StatelessWidget {
  final Color color;
  final IconData icon;
  const _MapPin({required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.white, width: 2),
            boxShadow: [
              BoxShadow(
                  color: color.withOpacity(0.4),
                  blurRadius: 10,
                  offset: const Offset(0, 4))
            ],
          ),
          child: Icon(icon, color: AppColors.white, size: 22),
        ),
        CustomPaint(
            size: const Size(12, 8),
            painter: _TailPainter(color: color)),
      ],
    );
  }
}

class _TailPainter extends CustomPainter {
  final Color color;
  const _TailPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(_) => false;
}

class _MapControlBtn extends StatelessWidget {
  final IconData icon;
  const _MapControlBtn({required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: const [
          BoxShadow(color: AppColors.cardShadow, blurRadius: 4)
        ],
      ),
      child: Icon(icon, size: 20, color: AppColors.textPrimary),
    );
  }
}

class _LocationRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  const _LocationRow(
      {required this.icon, required this.label, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 18, color: AppColors.textSecondary),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: GoogleFonts.inter(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary)),
              Text(subtitle,
                  style: GoogleFonts.inter(
                      fontSize: 11, color: AppColors.textSecondary)),
            ],
          ),
        ],
      ),
    );
  }
}

class _PrivateMapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height),
        Paint()..color = const Color(0xFFEEF2F7));

    final roadPaint = Paint()
      ..color = AppColors.white
      ..strokeWidth = 10
      ..style = PaintingStyle.stroke;
    final minorRoad = Paint()
      ..color = AppColors.white
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke;

    // Main roads
    canvas.drawLine(Offset(0, size.height * 0.5),
        Offset(size.width, size.height * 0.5), roadPaint);
    canvas.drawLine(Offset(size.width * 0.4, 0),
        Offset(size.width * 0.4, size.height), roadPaint);
    // Minor roads
    canvas.drawLine(Offset(0, size.height * 0.25),
        Offset(size.width, size.height * 0.25), minorRoad);
    canvas.drawLine(Offset(0, size.height * 0.75),
        Offset(size.width, size.height * 0.75), minorRoad);
    canvas.drawLine(Offset(size.width * 0.7, 0),
        Offset(size.width * 0.7, size.height), minorRoad);

    // River
    final river = Paint()
      ..color = const Color(0xFFB3D4E8)
      ..strokeWidth = 14
      ..style = PaintingStyle.stroke;
    final path = Path()
      ..moveTo(size.width * 0.1, 0)
      ..quadraticBezierTo(
          size.width * 0.5, size.height * 0.4,
          size.width, size.height * 0.55);
    canvas.drawPath(path, river);

    // Blocks
    final blockPaint =
        Paint()..color = const Color(0xFFD0DAE0).withOpacity(0.7);
    final blocks = [
      [0.0, 0.0, 0.38, 0.22],
      [0.42, 0.0, 0.26, 0.22],
      [0.72, 0.0, 0.28, 0.22],
      [0.0, 0.28, 0.22, 0.2],
      [0.42, 0.28, 0.26, 0.2],
      [0.72, 0.28, 0.26, 0.2],
      [0.0, 0.55, 0.38, 0.18],
      [0.0, 0.78, 0.38, 0.22],
      [0.42, 0.55, 0.56, 0.22],
      [0.42, 0.78, 0.56, 0.22],
    ];
    for (final b in blocks) {
      canvas.drawRect(
        Rect.fromLTWH(size.width * b[0] + 2, size.height * b[1] + 2,
            size.width * b[2] - 4, size.height * b[3] - 4),
        blockPaint,
      );
    }

    // Road labels
    final textPainter = TextPainter(
      text: TextSpan(
          text: 'Digos City',
          style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: const Color(0xFF7A8A96).withOpacity(0.8))),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(
        canvas,
        Offset(size.width * 0.4 - textPainter.width / 2,
            size.height * 0.5 + 8));
  }

  @override
  bool shouldRepaint(_) => false;
}
