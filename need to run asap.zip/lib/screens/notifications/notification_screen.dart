import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/dummy_data.dart';
import '../../core/utils/helpers.dart';
import '../../models/notification_model.dart';
import '../../widgets/cards/notification_card.dart';

class NotificationScreen extends StatefulWidget {
  final bool embedded;
  const NotificationScreen({super.key, this.embedded = false});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  late List<AppNotification> _notifications;

  @override
  void initState() {
    super.initState();
    _notifications = List.from(DummyData.notifications);
  }

  void _markAllRead() {
    setState(() {
      _notifications =
          _notifications.map((n) => n.copyWith(isRead: true)).toList();
    });
  }

  int get _unreadCount => _notifications.where((n) => !n.isRead).length;

  List<AppNotification> get _today => _notifications
      .where((n) => DateTime.now().difference(n.timestamp).inHours < 24)
      .toList();
  List<AppNotification> get _yesterday => _notifications
      .where((n) {
        final diff = DateTime.now().difference(n.timestamp);
        return diff.inHours >= 24 && diff.inHours < 48;
      })
      .toList();
  List<AppNotification> get _earlier => _notifications
      .where((n) => DateTime.now().difference(n.timestamp).inHours >= 48)
      .toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              color: AppColors.white,
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
              child: Row(
                children: [
                  if (!widget.embedded) ...[
                    IconButton(
                      icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
                      onPressed: () => Navigator.pop(context),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                    const SizedBox(width: 8),
                  ],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Text('Notifications',
                              style: GoogleFonts.inter(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.textPrimary)),
                          if (_unreadCount > 0) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppColors.primary,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text('$_unreadCount new',
                                  style: GoogleFonts.inter(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.white)),
                            ),
                          ],
                        ]),
                      ],
                    ),
                  ),
                  if (_unreadCount > 0)
                    TextButton(
                      onPressed: _markAllRead,
                      child: Text('Mark all read',
                          style: GoogleFonts.inter(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.primary)),
                    ),
                ],
              ),
            ),
            const Divider(height: 1, color: AppColors.divider),

            // List
            Expanded(
              child: _notifications.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: const BoxDecoration(
                              color: AppColors.primarySurface,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                                Icons.notifications_none_rounded,
                                color: AppColors.primary,
                                size: 36),
                          ),
                          const SizedBox(height: 16),
                          Text('No notifications yet',
                              style: GoogleFonts.inter(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary)),
                          const SizedBox(height: 6),
                          Text(
                              "You'll be notified when\nyour report status changes.",
                              style: GoogleFonts.inter(
                                  fontSize: 13,
                                  color: AppColors.textSecondary),
                              textAlign: TextAlign.center),
                        ],
                      ),
                    )
                  : ListView(
                      padding: const EdgeInsets.all(16),
                      physics: const BouncingScrollPhysics(),
                      children: [
                        if (_today.isNotEmpty) ...[
                          _GroupLabel('Today'),
                          ..._today.map((n) => NotificationCard(
                              notification: n,
                              onTap: () => setState(
                                  () => _notifications = _notifications
                                      .map((x) => x.id == n.id
                                          ? x.copyWith(isRead: true)
                                          : x)
                                      .toList()))),
                        ],
                        if (_yesterday.isNotEmpty) ...[
                          _GroupLabel('Yesterday'),
                          ..._yesterday.map((n) => NotificationCard(notification: n)),
                        ],
                        if (_earlier.isNotEmpty) ...[
                          _GroupLabel('Earlier'),
                          ..._earlier.map((n) => NotificationCard(notification: n)),
                        ],
                        const SizedBox(height: 12),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GroupLabel extends StatelessWidget {
  final String label;
  const _GroupLabel(this.label);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, top: 4),
      child: Text(
        label,
        style: GoogleFonts.inter(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: AppColors.textHint,
            letterSpacing: 0.5),
      ),
    );
  }
}
